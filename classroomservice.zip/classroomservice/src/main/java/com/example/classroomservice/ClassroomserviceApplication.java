package com.example.classroomservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassroomserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassroomserviceApplication.class, args);
	}

}
