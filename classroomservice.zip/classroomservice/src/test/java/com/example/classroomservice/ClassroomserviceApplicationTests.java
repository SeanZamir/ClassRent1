package com.example.classroomservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassroomserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
